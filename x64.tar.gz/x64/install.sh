mkdir -p /usr/local/share/emacs/
cp -r 28.1 /usr/local/share/emacs/

mkdir -p /usr/local/share/emacs/28.1/etc/
cp -r 28.1/charsets /usr/local/share/emacs/28.1/etc/

mkdir -p /usr/local/bin/
cp bin/* /usr/local/bin/

rm -rf ~/.emacs.d
cp -r .emacs.d  ~/

export PATH=$PATH:/usr/local/bin/
LD_LIBRARY_PATH=/usr/local/share/emacs/28.1/lib emacs-28.1
